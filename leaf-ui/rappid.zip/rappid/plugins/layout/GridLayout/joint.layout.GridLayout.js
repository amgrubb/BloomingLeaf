/*! Rappid v2.3.1 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2018-05-17 


This Source Code Form is subject to the terms of the Rappid Academic License
, v. 1.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_academic_v1.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


joint.layout = joint.layout || {};

joint.layout.GridLayout = {

    layout: function(graphOrCells, opt) {

        var graph;

        if (graphOrCells instanceof joint.dia.Graph) {
            graph = graphOrCells;
        } else {
            // `dry: true` for not overriding original graph reference
            // `sort: false` to prevent elements to change their order based on the z-index
            graph = (new joint.dia.Graph()).resetCells(graphOrCells, { dry: true, sort: false });
        }

        // This is not needed anymore.
        graphOrCells = null;

        opt = opt || {};

        var elements = graph.getElements();

        // number of columns
        var columns = opt.columns || 1;
        var rows = Math.ceil(elements.length / columns);
        // shift the element horizontally by a given amount
        var dx = opt.dx || 0;

        // shift the element vertically by a given amount
        var dy = opt.dy || 0;
        // position the elements in the centre of a grid cell
        var centre = opt.centre === undefined || opt.centre !== false;

        // resize the elements to fit a grid cell & preserves ratio
        var resizeToFit = !!opt.resizeToFit;

        // coordinates of the most top-left element.
        var marginX = opt.marginX || 0;
        var marginY = opt.marginY || 0;

        // width of a column
        var columnWidths = [];
        var columnWidth = opt.columnWidth;
        if (columnWidth === 'compact') {

            for (var cIndex = 0; cIndex < columns; cIndex++) {
                var elementsAtColumn = this._elementsAtColumn(elements, cIndex, columns);
                columnWidths.push(this._maxDim(elementsAtColumn, 'width') + dx);
            }
        } else {
            if (!columnWidth || joint.util.isString(columnWidth)) {
                columnWidth = this._maxDim(elements, 'width') + dx;
            }
            for (var i = 0; i < columns; i++) {
                columnWidths.push(columnWidth);
            }
        }

        var columnsX = this._accumulate(columnWidths, marginX);

        // height of a row
        var rowHeights = [];
        var rowHeight = opt.rowHeight;
        if (rowHeight === 'compact') {
            for (var rIndex = 0; rIndex < rows; rIndex++) {
                var elementsAtRow = this._elementsAtRow(elements, rIndex, columns);
                rowHeights.push(this._maxDim(elementsAtRow, 'height') + dy);
            }
        } else {
            if (!rowHeight || joint.util.isString(rowHeight)) {
                rowHeight = this._maxDim(elements, 'height') + dy;
            }

            for (var j = 0; j < rows; j++) {
                rowHeights.push(rowHeight);
            }
        }

        var rowsY = this._accumulate(rowHeights, marginY);

        // Wrap all graph changes into a batch.
        graph.startBatch('layout');

        // iterate the elements and position them accordingly
        elements.forEach(function(element, index) {

            var cIndex = index % columns;
            var rIndex = Math.floor(index / columns);
            var cWidth = columnWidths[cIndex];
            var rHeight = rowHeights[rIndex];

            var cx = 0;
            var cy = 0;
            var elementSize = element.get('size');

            if (resizeToFit) {

                var elementWidth = cWidth - 2 * dx;
                var elementHeight = rHeight - 2 * dy;

                var calcElHeight = elementSize.height * (elementSize.width ? elementWidth / elementSize.width : 1);
                var calcElWidth = elementSize.width * (elementSize.height ? elementHeight / elementSize.height : 1);

                if (calcElHeight > rHeight) {
                    elementWidth = calcElWidth;
                } else {
                    elementHeight = calcElHeight;
                }

                elementSize = { width: elementWidth, height: elementHeight };
                element.set('size', elementSize, opt);
            }

            if (centre) {
                cx = (cWidth - elementSize.width) / 2;
                cy = (rHeight - elementSize.height) / 2;
            }

            element.position(columnsX[cIndex] + dx + cx, rowsY[rIndex] + dy + cy, opt);
        });

        graph.stopBatch('layout');
    },

    // find maximal dimension (width/height) in an array of the elements
    _maxDim: function(elements, dimension) {
        return elements.reduce(function(max, el) {
            return Math.max(el.get('size')[dimension], max);
        }, 0);
    },

    _elementsAtRow: function(elements, rowIndex, numberOfColumns) {
        var elementsAtRow = [];
        var i = numberOfColumns * rowIndex;
        var n = i + numberOfColumns;
        for (; i < n; i++) {
            elementsAtRow.push(elements[i]);
        }
        return elementsAtRow;
    },

    _elementsAtColumn: function(elements, columnIndex, numberOfColumns) {
        var elementsAtColumn = [];
        var i = columnIndex;
        var n = elements.length;
        for (; i < n; i += numberOfColumns) {
            elementsAtColumn.push(elements[i]);
        }
        return elementsAtColumn;
    },

    _accumulate: function(array, baseVal) {
        return array.reduce(function(res, val, i) {
            res.push(res[i] + val);
            return res;
        }, [baseVal || 0]);
    }
};
