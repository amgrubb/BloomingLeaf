/*! Rappid v2.3.1 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2018-05-17 


This Source Code Form is subject to the terms of the Rappid Academic License
, v. 1.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_academic_v1.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


// eslint-disable-next-line no-unused-vars
var SampleGraph = function(graph) {

    var COLORS = [
        '#263238',
        '#37474f',
        '#546e7a',
        '#607d8b',
        '#78909c',
        '#90a4ae',
        '#cfd8dc',
        '#0d47a1',
        '#33691e',
        '#bf360c'
    ];

    var COLORS_B = [
        '#757575',
        '#9e9e9e',
        '#bdbdbd',
        '#e0e0e0'
    ];

    return {
        create: function() {

            var cells = [];
            for (var i = 0; i < 40; i++) {

                var size = _.random(10, 100);

                cells.push(
                    new joint.shapes.basic.Circle({
                        position: { x: _.random(0, 400), y: _.random(0, 200) },
                        size: { width: size, height: size },
                        attrs: {
                            circle: {
                                fill: COLORS[_.random(0, COLORS.length - 1)],
                                stroke: '#b0bec5',
                                strokeWidth: 1
                            }
                        }
                    })
                );

                cells.push(
                    new joint.shapes.basic.Circle({
                        position: { x: _.random(500, 950), y: _.random(0, 200) },
                        size: { width: size, height: size },
                        attrs: {
                            circle: {
                                fill: COLORS_B[_.random(0, COLORS_B.length - 1)],
                                stroke: '#b0bec5',
                                strokeWidth: 1
                            }
                        }
                    })
                );

                cells.push(
                    new joint.shapes.basic.Rect({
                        position: { x: _.random(500, 950), y: _.random(300, 600) },
                        size: { width: size, height: size },
                        attrs: {
                            rect: {
                                fill: COLORS[_.random(0, COLORS.length - 1)],
                                stroke: '#b0bec5',
                                strokeWidth: 1
                            }
                        }
                    })
                );

                cells.push(
                    new joint.shapes.basic.Rect({
                        position: { x: _.random(0, 400), y: _.random(300, 600) },
                        size: { width: size, height: size },
                        attrs: {
                            rect: {
                                fill: COLORS_B[_.random(0, COLORS_B.length - 1)],
                                stroke: '#b0bec5',
                                strokeWidth: 1
                            }
                        }
                    })
                );
            }

            graph.resetCells(cells);
        }
    };
};