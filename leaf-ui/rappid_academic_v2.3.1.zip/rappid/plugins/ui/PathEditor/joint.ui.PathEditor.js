/*! Rappid v2.3.1 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2018-05-17 


This Source Code Form is subject to the terms of the Rappid Academic License
, v. 1.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_academic_v1.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


joint.ui.PathEditor = joint.mvc.View.extend({

    tagName: 'g',

    svgElement: true,

    className: 'path-editor',

    events: {
        'mousedown .anchor-point': 'onAnchorPointPointerDown',
        'mousedown .control-point': 'onControlPointPointerDown',
        'mousedown .segment-path': 'onSegmentPathPointerDown',
        //'mousemove': 'onPointerMove', // only bound (while mousedown)
        //'mouseup': 'onPointerUp', // only bound (ends mousedown)
        'touchstart .anchor-point': 'onAnchorPointPointerDown',
        'touchstart .control-point': 'onControlPointPointerDown',
        'touchstart .segment-path': 'onSegmentPathPointerDown',
        //'touchmove': 'onPointerMove', // only bound (while touch)
        //'touchup': 'onPointerUp', // only bound (ends touch)
        'dblclick .anchor-point': 'onAnchorPointDoubleClick',
        'dblclick .control-point': 'onControlPointDoubleClick',
        'dblclick .segment-path': 'onSegmentPathDoubleClick'
    },

    options: {
        anchorPointMarkup: '<circle r="2.5"/>',
        controlPointMarkup: '<circle r="2.5"/>'
    },

    init: function() {

        var pathNode = this.pathNode = V(this.options.pathElement).normalizePath().node;

        this.segList = pathNode.pathSegList;
        this.svgRoot = V(pathNode.ownerSVGElement);
        this.$document = $(pathNode.ownerDocument);

        this.render();
    },

    bindDocumentEvents: function() {

        var eventNS = this.getEventNamespace();
        this.$document.on('mousemove' + eventNS + ' touchmove' + eventNS, _.bind(this.onPointerMove, this));
        this.$document.on('mouseup' + eventNS + ' touchend' + eventNS, _.bind(this.onPointerUp, this));
    },

    unbindDocumentEvents: function() {

        this.$document.off(this.getEventNamespace());
    },

    onRemove: function() {

        this.unbindDocumentEvents();
        this.clear();
    },

    clear: function() {

        var vel = this.vel;
        vel.empty();

        this.directionPaths = [];
        this.segmentPaths = [];
        this.controlPoints = [];
        this.anchorPoints = [];

        // first subPath always start at index '0'
        this._subPathIndices = [0];

        this.trigger('clear', this.pathNode);
    },

    _transformPoint: function(x, y, matrix) {
        return V.transformPoint(g.Point(x, y), matrix);
    },

    render: function() {

        this.clear();

        var vel = this.vel;

        var ctm = this.pathNode.getCTM();

        var anchorTpl = V(this.options.anchorPointMarkup).addClass('anchor-point');
        var controlTpl = V(this.options.controlPointMarkup).addClass('control-point');
        var directionPathTpl = V('<path class="direction-path"/>');
        var segPathTpl = V('<path class="segment-path"/>');

        var segList = this.segList;

        var anchorPoints = this.anchorPoints;
        var controlPoints = this.controlPoints;
        var directionPaths = this.directionPaths;
        var segmentPaths = this.segmentPaths;

        var _subPathIndices = this._subPathIndices;

        var index;
        var prevX;
        var prevY;
        for (index = 0, prevX = 0, prevY = 0; index < segList.numberOfItems; index++) {

            var seg = segList.getItem(index);

            var segPoint = this._transformPoint(seg.x, seg.y, ctm);
            var x = segPoint.x;
            var y = segPoint.y;

            if (seg.pathSegType != SVGPathSeg.PATHSEG_CLOSEPATH) {

                anchorPoints[index] = anchorTpl.clone().attr({
                    index: index,
                    cx: x,
                    cy: y
                });
            }

            if (seg.pathSegType != SVGPathSeg.PATHSEG_MOVETO_ABS) {

                var segPath = segPathTpl.clone().attr('index', index).node;
                segPath.pathSegList.initialize(segPath.createSVGPathSegMovetoAbs(prevX, prevY));

                switch (seg.pathSegType) {

                    case SVGPathSeg.PATHSEG_CLOSEPATH:
                        var subPathStartSeg = segList.getItem(_subPathIndices[0]);

                        var subPathStartSegPoint = this._transformPoint(subPathStartSeg.x, subPathStartSeg.y, ctm);
                        x = subPathStartSegPoint.x;
                        y = subPathStartSegPoint.y;

                        segPath.pathSegList.appendItem(segPath.createSVGPathSegLinetoAbs(x, y));
                        _subPathIndices.unshift(index + 1);
                        break;

                    case SVGPathSeg.PATHSEG_LINETO_ABS:
                        segPath.pathSegList.appendItem(segPath.createSVGPathSegLinetoAbs(x, y));
                        break;

                    case SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS:
                        var controlSegPoint1 = this._transformPoint(seg.x1, seg.y1, ctm);
                        var controlPt1 = controlTpl.clone().attr({
                            index: index,
                            'attribute-index': 1,
                            cx: controlSegPoint1.x,
                            cy: controlSegPoint1.y
                        });

                        var controlSegPoint2 = this._transformPoint(seg.x2, seg.y2, ctm);
                        var controlPt2 = controlTpl.clone().attr({
                            index: index,
                            'attribute-index': 2,
                            cx: controlSegPoint2.x,
                            cy: controlSegPoint2.y
                        });

                        controlPoints[index] = [controlPt1, controlPt2];

                        segPath.pathSegList.appendItem(segPath.createSVGPathSegCurvetoCubicAbs(x, y, controlSegPoint1.x, controlSegPoint1.y, controlSegPoint2.x, controlSegPoint2.y));

                        directionPaths[index] = [
                            directionPathTpl.clone().attr('d', ['M', prevX, prevY, 'L', controlSegPoint1.x, controlSegPoint1.y].join(' ')),
                            directionPathTpl.clone().attr('d', ['M', x, y, 'L', controlSegPoint2.x, controlSegPoint2.y].join(' '))
                        ];
                        break;
                }

                segmentPaths[index] = segPath;
            }

            prevX = x;
            prevY = y;

        }

        vel.append(_.filter(segmentPaths))
            .append(_.flatten( _.filter(directionPaths)))
            .append(_.filter(anchorPoints))
            .append(_.flatten( _.filter(controlPoints)));

        this.svgRoot.append(vel);
    },

    startMoving: function(e) {

        var evt = joint.util.normalizeEvent(e);

        var $point = this.$point = $(evt.target);

        this.prevClientX = evt.clientX;
        this.prevClientY = evt.clientY;

        var index = parseInt(this.$point.attr('index'), 10);

        if ($point.hasClass('anchor-point')) {

            this.trigger('path:interact');
            this.trigger('path:anchor-point:select', index);
            // first clickable anchor point is 0

        } else if ($point.hasClass('control-point')) {

            var controlPointIndex = this.$point.attr('attribute-index');
            this.trigger('path:interact');
            this.trigger('path:control-point:select', index, controlPointIndex);
            // the index refers to the index of the curveto segment this control point belongs to
            // curveto path's control point 1 has index 1, control point 2 has index 2
            // first clickable control point is at 1, 1 (even though the point has a direction path connected to anchor point 0)

        } else {

            this.trigger('path:interact');
            this.trigger('path:segment:select', index);
            // first clickable segment is segment 1
            // segment 0 is the first M segment (which has no path)

        }

        evt.stopPropagation();
        evt.preventDefault();

        this.pathEditedEventType = null;
    },

    move: function(e) {

        var $point = this.$point;

        if (!$point) return;

        // move anchor and control points
        var evt = joint.util.normalizeEvent(e);
        var dx = evt.clientX - this.prevClientX;
        var dy = evt.clientY - this.prevClientY;

        var index = parseInt($point.attr('index'), 10);

        if ($point.hasClass('anchor-point')) {

            // move anchor point
            this.adjustAnchorPoint(index, dx, dy);

        } else if ($point.hasClass('control-point')) {

            // move control point
            var controlPointIndex = $point.attr('attribute-index');
            this.adjustControlPoint(index, controlPointIndex, dx, dy);

        } else {

            // move segment path
            this.adjustAnchorPoint(index - 1, dx, dy);
            this.adjustAnchorPoint(index, dx, dy);

        }

        // move the direction paths

        this.prevClientX = evt.clientX;
        this.prevClientY = evt.clientY;
    },

    adjustControlPoint: function(index, controlPointIndex, dx, dy) {

        // get the path transformation matrix
        var ctm = this.pathNode.getCTM();

        var segList = this.segList;

        // the raw path data is not transformed
        var seg = segList.getItem(index);

        var controlPoints = this.controlPoints;

        // the client movement data is transformed because it comes from interaction events in a transformed viewport
        // convert to untransformed coordinates to match the path's underlying representation (untransformed)
        var inverseCTM = ctm.inverse();
        // translations are ignored since we are interested in differences in position
        inverseCTM.e = 0;
        inverseCTM.f = 0;
        var movePoint = this._transformPoint(dx, dy, inverseCTM);

        // apply untransformed client movement data to untransformed path data
        var xA = 'x' + controlPointIndex;
        var yA = 'y' + controlPointIndex;
        seg[xA] += movePoint.x;
        seg[yA] += movePoint.y;

        // convert to transformed coordinates to match how path is rendered on screen
        var controlSegPoint = this._transformPoint(seg[xA], seg[yA], ctm);
        var controlPt = controlPoints[index][controlPointIndex - 1].attr({
            cx: controlSegPoint.x,
            cy: controlSegPoint.y
        });

        if (controlPt.hasClass('locked')) {

            // this control point is locked with another control point
            // we also need to modify the bound control point
            var boundIndex = this.getBoundIndex(index, controlPointIndex);
            var boundControlPointIndex = ((controlPointIndex == 1) ? 2 : 1);
            var bindSeg = segList.getItem(boundIndex);

            // recalculate bound point with untransformed coordinates
            var xB = 'x' + boundControlPointIndex;
            var yB = 'y' + boundControlPointIndex;
            var center = g.point(((controlPointIndex == 1) ? bindSeg.x : seg.x), ((controlPointIndex == 1) ? bindSeg.y : seg.y));
            var controlPos = g.point(seg[xA], seg[yA]);
            var distance = center.distance(g.Point(bindSeg[xB], bindSeg[yB]));
            var bindControlPos = center.move(controlPos, distance);
            bindSeg[xB] = bindControlPos.x;
            bindSeg[yB] = bindControlPos.y;

            // convert to transformed coodinates
            var bindControlSegPoint = this._transformPoint(bindSeg[xB], bindSeg[yB], ctm);
            controlPoints[boundIndex][boundControlPointIndex - 1].attr({
                cx: bindControlSegPoint.x,
                cy: bindControlSegPoint.y
            });

            // update paths involving bound control point
            this.updateDirectionPaths(boundIndex);
            this.updateSegmentPath(boundIndex);
        }

        // update paths involving control point
        this.updateDirectionPaths(index);
        this.updateSegmentPath(index);

        this.pathEditedEventType = 'path:control-point:adjust';
    },

    adjustAnchorPoint: function(index, dx, dy) {

        // get the path transformation matrix
        var ctm = this.pathNode.getCTM();

        var segList = this.segList;

        // the raw path data is not transformed
        var seg = segList.getItem(index);
        var _subPathIndices = this._subPathIndices;
        if (seg.pathSegType == SVGPathSeg.PATHSEG_CLOSEPATH) {
            index = _.find(_subPathIndices, function(i) { return i < index; });
            seg = segList.getItem(index);
        }

        var anchorPoints = this.anchorPoints;
        var controlPoints = this.controlPoints;

        // if we move either endpoint, control points across start anchor point must be unlocked
        var lastIndex = anchorPoints.length - 1;
        if ((index === 0 || index === lastIndex) && controlPoints[1] && controlPoints[lastIndex]) {
            var controlPoint1 = controlPoints[1][0];
            var controlPoint2 = controlPoints[lastIndex][1];

            if (controlPoint1 && controlPoint1.hasClass('locked')) controlPoint1.removeClass('locked');
            if (controlPoint2 && controlPoint2.hasClass('locked')) controlPoint2.removeClass('locked');
        }

        // the client movement data is transformed because it comes from interaction events in a transformed viewport
        // convert to untransformed coordinates to match the path's underlying representation (untransformed)
        var inverseCTM = ctm.inverse();
        // translations are ignored since we are interested in differences in position
        inverseCTM.e = 0;
        inverseCTM.f = 0;
        var movePoint = this._transformPoint(dx, dy, inverseCTM);

        // apply untransformed client movement data to untransformed path data
        seg.x += movePoint.x;
        seg.y += movePoint.y;

        // convert to transformed coordinates to match how path is rendered on screen
        var segPoint = this._transformPoint(seg.x, seg.y, ctm);
        anchorPoints[index].attr({
            cx: segPoint.x,
            cy: segPoint.y
        });

        if (seg.pathSegType == SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS) {
            // apply untransformed client movement data to untransformed path data
            seg.x2 += movePoint.x;
            seg.y2 += movePoint.y;

            // convert to transformed coordinates
            var controlSegPoint = this._transformPoint(seg.x2, seg.y2, ctm);
            controlPoints[index][1].attr({
                cx: controlSegPoint.x,
                cy: controlSegPoint.y
            });
        }

        var nextSeg = ((index + 1) < segList.numberOfItems) ? segList.getItem(index + 1) : 0;

        if (nextSeg) {
            if (nextSeg.pathSegType == SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS) {
                // apply untransformed client movement data to untransformed path data
                nextSeg.x1 += movePoint.x;
                nextSeg.y1 += movePoint.y;

                // convert to transformed coordinates
                var nextControlSegPoint = this._transformPoint(nextSeg.x1, nextSeg.y1, ctm);
                controlPoints[index + 1][0].attr({
                    cx: nextControlSegPoint.x,
                    cy: nextControlSegPoint.y
                });

                // update control paths involving next anchor point
                this.updateDirectionPaths(index + 1);
            }

            // update segment path involving next anchor point
            this.updateSegmentPath(index + 1);
        }

        // update paths involving this anchor point
        this.updateDirectionPaths(index);
        this.updateSegmentPath(index);

        this.pathEditedEventType = 'path:anchor-point:adjust';
    },

    // updates paths from a given segment to control points
    updateDirectionPaths: function(index) {

        // get the path transformation matrix
        var ctm = this.pathNode.getCTM();

        var segList = this.segList;

        // raw path data is unconverted
        // convert to transformed coordinates to match how path is rendered on screen
        var seg = segList.getItem(index);
        var segPoint = this._transformPoint(seg.x, seg.y, ctm);

        // make sure that previous segment exists
        var prevSeg = (index > 0) ? segList.getItem(index - 1) : null;
        var prevSegPoint = prevSeg ? this._transformPoint(prevSeg.x, prevSeg.y, ctm) : null;

        // for each direction path from this anchor point
        _.each(this.directionPaths[index], function(directionPath, i) {

            i++;

            var controlSegPoint = this._transformPoint(seg['x' + i], seg['y' + i], ctm);

            // update the path with transformed coordinates
            directionPath.attr('d', [
                'M',
                (i > 1 || !prevSeg) ? segPoint.x : prevSegPoint.x,
                (i > 1 || !prevSeg) ? segPoint.y : prevSegPoint.y,
                controlSegPoint.x,
                controlSegPoint.y
            ].join(' '));

        }, this);
    },

    // updates given path
    updateSegmentPath: function(index) {

        var segList = this.segList;

        var _subPathIndices = this._subPathIndices;

        if (_subPathIndices.includes(index)) {

            var segMaxIndex = _.find(_subPathIndices.slice().reverse(), function(i) { return (i > index); }) || segList.numberOfItems;

            segMaxIndex--;

            if (segList.getItem(segMaxIndex).pathSegType != SVGPathSeg.PATHSEG_CLOSEPATH) return;

            index = segMaxIndex;
        }

        // first segment (index = 0) is always 'M' and such it has no segmentPath
        var segPath = this.segmentPaths[index];
        if (!segPath) return;

        // get the path transformation matrix
        var ctm = this.pathNode.getCTM();

        // there is always a previous segment because we are skipping over the first segment
        // raw path data is untransformed
        // convert to transformed coordinates to match how path is rendered on screen
        var prevSeg = segList.getItem(index - 1);
        var prevSegPoint = this._transformPoint(prevSeg.x, prevSeg.y, ctm);
        // create the updated path
        var item = segPath.createSVGPathSegMovetoAbs(prevSegPoint.x, prevSegPoint.y);
        segPath.pathSegList.initialize(item);

        // transform path data to match path rendering
        var seg = segList.getItem(index);
        var segPoint = this._transformPoint(seg.x, seg.y, ctm);

        switch (seg.pathSegType) {

            case SVGPathSeg.PATHSEG_CLOSEPATH:
                // transform path data to match path rendering
                var nextSeg = segList.getItem(_.find(_subPathIndices, function(i) { return (i < index); }));
                var nextSegPoint = this._transformPoint(nextSeg.x, nextSeg.y, ctm);
                item = segPath.createSVGPathSegLinetoAbs(nextSegPoint.x, nextSegPoint.y);
                break;

            case SVGPathSeg.PATHSEG_LINETO_ABS:
                item = segPath.createSVGPathSegLinetoAbs(segPoint.x, segPoint.y);
                break;

            case SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS:
                // transform control point data to match path rendering
                var controlSegPoint1 = this._transformPoint(seg.x1, seg.y1, ctm);
                var controlSegPoint2 = this._transformPoint(seg.x2, seg.y2, ctm);
                item = segPath.createSVGPathSegCurvetoCubicAbs(segPoint.x, segPoint.y, controlSegPoint1.x, controlSegPoint1.y, controlSegPoint2.x, controlSegPoint2.y);
                break;
        }

        segPath.pathSegList.appendItem(item);
    },

    stopMoving: function() {

        this.$point = null;

        // only trigger events after the moving stops
        if (this.pathEditedEventType) {
            var pathNode = this.pathNode;

            this.trigger('path:edit', pathNode);
            this.trigger(this.pathEditedEventType, pathNode);
        }

        this.pathEditedEventType = null;
    },

    createAnchorPoint: function(e) {

        var evt = joint.util.normalizeEvent(e);
        var index = V(evt.target).attr('index');
        var pathNode = this.pathNode;
        var segList = this.segList;

        var pt = V(pathNode).toLocalPoint(evt.pageX, evt.pageY);
        var seg = segList.getItem(index);

        switch (seg.pathSegType) {

            case SVGPathSeg.PATHSEG_CLOSEPATH:
            case SVGPathSeg.PATHSEG_LINETO_ABS:
                segList.insertItemBefore(pathNode.createSVGPathSegLinetoAbs(pt.x, pt.y), index);
                break;

            case SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS:
                var pseg = segList.getItem(index - 1);
                var p0 = g.point(pseg.x, pseg.y);
                var p1 = g.point(seg.x1, seg.y1);
                var p2 = g.point(seg.x2, seg.y2);
                var p3 = g.point(seg.x, seg.y);

                // Inversion of Bezier curve
                var t = g.bezier.getInversionSolver(p0, p1, p2, p3)(pt);

                // TODO: wen a curve is a straight line we will get inaccurate results
                if (t < 0) return;

                // Divide a Bezier curve into two
                var curves = g.bezier.getCurveDivider(p0, p1, p2, p3)(t);

                segList.insertItemBefore(pathNode.createSVGPathSegCurvetoCubicAbs(
                    curves[0].p3.x,
                    curves[0].p3.y,
                    curves[0].p1.x,
                    curves[0].p1.y,
                    curves[0].p2.x,
                    curves[0].p2.y
                ), index);

                seg.x1 = curves[1].p1.x;
                seg.y1 = curves[1].p1.y;
                seg.x2 = curves[1].p2.x;
                seg.y2 = curves[1].p2.y;
                break;
        }

        this.render();

        this.trigger('path:edit', pathNode);
        this.trigger('path:anchor-point:create', pathNode);
    },

    removeAnchorPoint: function(e) {

        var evt = joint.util.normalizeEvent(e);
        var index = parseInt($(evt.target).attr('index'), 10);

        var pathNode = this.pathNode;
        var segList = this.segList;

        var seg = segList.getItem(index);

        var nseg;
        var rseg;

        switch (seg.pathSegType) {

            case SVGPathSeg.PATHSEG_MOVETO_ABS:
                // replace following segment with moveto
                // then delete this moveto
                nseg = segList.getItem(index + 1);
                rseg = pathNode.createSVGPathSegMovetoAbs(nseg.x, nseg.y);
                segList.replaceItem(rseg, index + 1);
                segList.removeItem(index);
                break;

            case SVGPathSeg.PATHSEG_LINETO_ABS:
                // just remove this segment
                segList.removeItem(index);
                break;

            case SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS:
                // replace following curve's control point 1 with this curve's control point 1
                // if not followed by a curve, then discard the curve information
                // then delete this curveto
                if ((index + 1) <= (segList.numberOfItems - 1)) {
                    nseg = segList.getItem(index + 1);
                    if (nseg.pathSegType == SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS) {
                        nseg.x1 = seg.x1;
                        nseg.y1 = seg.y1;
                    }
                }
                segList.removeItem(index);
                break;
        }

        this.render();

        this.trigger('path:edit', pathNode);
        this.trigger('path:anchor-point:remove', pathNode);

        var numAnchorPoints = segList.numberOfItems;
        if (segList.getItem(segList.numberOfItems - 1).pathSegType == SVGPathSeg.PATHSEG_CLOSEPATH) {
            numAnchorPoints -= 1;
        }

        if (numAnchorPoints < 2) {
            // the path has too few points to be seen
            this.trigger('path:invalid', pathNode);
        }
    },

    lockControlPoint: function(e) {

        var evt = joint.util.normalizeEvent(e);
        var evtTarget = $(evt.target);

        var pathNode = this.pathNode;

        var index = parseInt(evtTarget.attr('index'));
        var controlPointIndex = evtTarget.attr('attribute-index');

        var boundIndex = this.getBoundIndex(index, controlPointIndex);
        var boundControlPointIndex = ((controlPointIndex == 1) ? 2 : 1);

        var boundControlPoint = this.controlPoints[boundIndex];

        if (boundControlPoint) {

            var isLocked = evtTarget.hasClass('locked');

            evtTarget.toggleClass('locked');
            boundControlPoint[boundControlPointIndex - 1].toggleClass('locked');

            this.trigger('path:interact');
            if (!isLocked) this.trigger('path:control-point:lock', index, controlPointIndex);
            else this.trigger('path:control-point:unlock', index, controlPointIndex);

            this.adjustControlPoint(index, controlPointIndex, 0, 0); // updates pathEditedEventType
            this.trigger('path:edit', pathNode);
            this.trigger(this.pathEditedEventType, pathNode);
            this.pathEditedEventType = null;
        }
    },

    getBoundIndex: function(index, controlPointIndex) {

        var boundIndex;

        var segList = this.segList;
        var lastSegIndex;
        var lastSegType;
        var closepathPresent;

        var anchorPoints = this.anchorPoints;
        var lastIndex = anchorPoints.length - 1;
        var endpointsIdenticalX;
        var endpointsIdenticalY;

        if (controlPointIndex == 1) {

            boundIndex = index - 1;

            if (boundIndex === 0) {
                // if we are trying to wrap past the start element

                lastSegIndex = segList.numberOfItems - 1;
                lastSegType = segList.getItem(lastSegIndex).pathSegType;
                closepathPresent = (lastSegType == SVGPathSeg.PATHSEG_CLOSEPATH);

                endpointsIdenticalX = anchorPoints[0].attr('cx') === anchorPoints[lastIndex].attr('cx');
                endpointsIdenticalY = anchorPoints[0].attr('cy') === anchorPoints[lastIndex].attr('cy');

                if (closepathPresent && endpointsIdenticalX && endpointsIdenticalY) {
                    // there is a closepath segment between the start element and the last element AND
                    // the start element and the last element have the same coordinates
                    // (that is, the two curves look like any other curve join in the path)

                    boundIndex = lastIndex; // wrap to the last element

                } // else leave the index at 0 (no control points correspond to the index)
            }

        } else {

            boundIndex = index + 1;

            if (boundIndex === (lastIndex + 1)) {
                // if we are trying to wrap past the last element

                lastSegIndex = segList.numberOfItems - 1;
                lastSegType = segList.getItem(lastSegIndex).pathSegType;
                closepathPresent = (lastSegType == SVGPathSeg.PATHSEG_CLOSEPATH);

                endpointsIdenticalX = anchorPoints[0].attr('cx') === anchorPoints[lastIndex].attr('cx');
                endpointsIdenticalY = anchorPoints[0].attr('cy') === anchorPoints[lastIndex].attr('cy');

                if (closepathPresent && endpointsIdenticalX && endpointsIdenticalY) {
                    // there is a closepath segment between the last element and the start element AND
                    // the start element and the last element have the same coordinates
                    // (that is, the two curves look like any other curve join in the path)

                    boundIndex = 1; // wrap to the first element

                } // else leave the index at (lastIndex + 1) (no control points correspond to the index)
            }
        }

        return boundIndex;
    },

    getControlPointLockedStates: function() {

        var controlPoints = this.controlPoints;

        var lockedStates = [];
        for (var index = 0; index < controlPoints.length; index++) {

            if (!controlPoints[index]) continue;

            lockedStates[index] = [];
            for (var j = 0; j <= 1; j++) {

                if (!controlPoints[index][j]) continue;

                var controlPointIndex = j + 1;

                if (controlPoints[index][j].hasClass('locked')) {
                    lockedStates[index][controlPointIndex] = true;

                } else {
                    lockedStates[index][controlPointIndex] = false;
                }
            }
        }

        return lockedStates;
    },

    setControlPointLockedStates: function(lockedStates) {

        var controlPoints = this.controlPoints;

        for (var index = 0; index < controlPoints.length; index++) {

            if (!lockedStates[index]) continue;
            if (!controlPoints[index]) continue;

            for (var controlPointIndex = 1; controlPointIndex <= 2; controlPointIndex++) {

                if (!lockedStates[index][controlPointIndex]) continue;
                if (!controlPoints[index][controlPointIndex - 1]) continue;

                if (lockedStates[index][controlPointIndex] === true) {
                    controlPoints[index][controlPointIndex - 1].addClass('locked');
                } else {
                    controlPoints[index][controlPointIndex - 1].removeClass('locked');
                }
            }
        }
    },

    convertSegmentPath: function(e) {

        var evt = joint.util.normalizeEvent(e);
        var index = V(evt.target).attr('index');

        var pathNode = this.pathNode;
        var segList = this.segList;

        var seg = segList.getItem(index);

        var pseg;
        var nseg;

        switch (seg.pathSegType) {

            case SVGPathSeg.PATHSEG_CLOSEPATH:
                // converts closepath to curveto path
                // takes the coordinates of the initial point as destination coordinates
                // creates a duplicate point at initial point (no way around this in svg)
                // no way to reverse this duplication
                // reconnects with another closepath
                pseg = segList.getItem(index - 1);
                nseg = segList.getItem(0);
                segList.insertItemBefore(pathNode.createSVGPathSegCurvetoCubicAbs(nseg.x, nseg.y, pseg.x, pseg.y, nseg.x, nseg.y), index);
                break;

            case SVGPathSeg.PATHSEG_LINETO_ABS:
                // converts lineto path to curveto path
                // puts control points at the locations of the two endpoints of the line
                pseg = segList.getItem(index - 1);
                segList.replaceItem(pathNode.createSVGPathSegCurvetoCubicAbs(seg.x, seg.y, pseg.x, pseg.y, seg.x, seg.y), index);
                break;

            case SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS:
                // converts curveto path to lineto path
                // endpoints stay endpoints, but curve information discarded
                segList.replaceItem(pathNode.createSVGPathSegLinetoAbs(seg.x, seg.y), index);
                break;
        }

        this.render();

        this.trigger('path:edit', pathNode);
        this.trigger('path:segment:convert', pathNode);
    },

    addClosePathSegment: function(e) {

        var evt = joint.util.normalizeEvent(e);
        var index = parseInt($(evt.target).attr('index'), 10);

        var segList = this.segList;

        if (index === 0 || index === segList.numberOfItems - 1) {

            // if the first or last anchor was selected
            var seg = segList.getItem(segList.numberOfItems - 1);
            if (seg.pathSegType != SVGPathSeg.PATHSEG_CLOSEPATH) {
                var pathNode = this.pathNode;

                // if the last segment of path is not closepath
                // add closepath at the end of path
                segList.appendItem(pathNode.createSVGPathSegClosePath());

                this.render();

                this.trigger('path:edit', pathNode);
                this.trigger('path:closepath-segment:add', pathNode);
            }
        }
    },

    removeClosePathSegment: function(e) {

        var evt = joint.util.normalizeEvent(e);
        var index = V(evt.target).attr('index');

        var segList = this.segList;

        var seg = segList.getItem(index);

        if (seg.pathSegType == SVGPathSeg.PATHSEG_CLOSEPATH) {
            var pathNode = this.pathNode;

            segList.removeItem(index);

            this.render();

            this.trigger('path:edit', pathNode);
            this.trigger('path:closepath-segment:remove', pathNode);
        }
    },

    //////////////
    // Handlers //
    //////////////

    onAnchorPointPointerDown: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();

        // left button only
        if (evt.which !== 1) return;

        // first click only (if this was part of a double click)
        if (evt.originalEvent.detail > 1) return;

        this.startMoving(evt);

        this.bindDocumentEvents();
    },

    onControlPointPointerDown: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();

        // left button only
        if (evt.which !== 1) return;

        // first click only (if this was part of a double click)
        if (evt.originalEvent.detail > 1) return;

        this.startMoving(evt);

        this.bindDocumentEvents();
    },

    onSegmentPathPointerDown: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();

        // left button only
        if (evt.which !== 1) return;

        // first click only (if this was part of a double click)
        if (evt.originalEvent.detail > 1) return;

        this.startMoving(evt);

        this.bindDocumentEvents();
    },

    onPointerMove: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();

        this.move(evt);

    },

    onPointerUp: function(e) {

        this.unbindDocumentEvents();

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();

        this.stopMoving();

    },

    onAnchorPointDoubleClick: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();
        evt.preventDefault();

        // left button only
        if (evt.which !== 1) return;

        this.removeAnchorPoint(evt); // default user interaction method

        // alternative method that could be called by this interaction:
        //this.addClosePathSegment(evt);
    },

    onControlPointDoubleClick: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();
        evt.preventDefault();

        // left button only
        if (evt.which !== 1) return;

        this.lockControlPoint(evt);
    },

    onSegmentPathDoubleClick: function(e) {

        var evt = joint.util.normalizeEvent(e);

        evt.stopPropagation();
        evt.preventDefault();

        // left button only
        if (evt.which !== 1) return;

        this.createAnchorPoint(evt); // default user interaction method

        // alternative methods that could be called by this interaction:
        //this.convertSegmentPath(evt);
        //this.removeClosePathSegment(evt);
    }
});
