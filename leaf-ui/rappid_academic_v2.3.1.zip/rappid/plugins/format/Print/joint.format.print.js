/*! Rappid v2.3.1 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2018-05-17 


This Source Code Form is subject to the terms of the Rappid Academic License
, v. 1.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_academic_v1.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


(function($, V, joint) {

    /*
        Gotcha's:
        * IE won't show background images and colors unless the "Print background colors and images" option is on. [1]
        * SVG filters are removed if their ID attribute conflicts with other elements in the DOM. [2]

        [1] https://support.microsoft.com/en-us/kb/296326
        [2] https://stackoverflow.com/questions/19042282/svg-filters-after-cloning-svg
    */
    var MAX_ROWS = 200;
    var MAX_COLUMNS = 200;

    joint.dia.Paper.prototype.print = function(opt) {

        var options = resolveOptions(opt);
        var area = getArea.call(this, options);
        var printAreaElements = [];
        var printAreaObj;
        var $body = $(document.body);

        if (options.poster) {

            var posterPieceSize = getPosterPieceSize(area, options.poster);
            var pieces = splitArea(area, posterPieceSize);

            for (var i = 0; i < pieces.length; i++) {
                printAreaObj = this.preparePrintArea(pieces[i], options);
                printAreaElements.push(printAreaObj.$el);
            }
        } else {
            printAreaObj = this.preparePrintArea(area, options);
            printAreaElements.push(printAreaObj.$el);
        }

        if (printAreaObj) {
            injectPrintCss(printAreaObj.css, options);
        }

        options.ready(printAreaElements, function(printAreaElements) {

            if (printAreaElements) {

                $body.addClass('joint-print');

                /*
                    Detach the children of the paper element before adding the cloned paper element to the DOM.
                    This is necessary because otherwise the SVG filters are removed because of duplicate element IDs.
                */
                var $detachedChildren = this.$el.children().detach();

                printAreaElements.forEach(function($el) {
                    $el.removeClass('preview').addClass('print-ready');
                    $el.prependTo(document.body);
                });

                var called = false;
                var onceAfterPrint = function() {

                    if (!called) {
                        called = true;

                        $body.removeClass('joint-print');

                        printAreaElements.forEach(function($el) {
                            $el.remove();
                        });

                        this.$el.append($detachedChildren);

                        this.trigger('afterprint', opt);
                        $(window).off('afterprint', onceAfterPrint);
                    }
                }.bind(this);

                $(window).one('afterprint', onceAfterPrint);

                // To make sure an app won't get stuck without its original body, add a delayed version.
                setTimeout(onceAfterPrint, 200);
                window.print();
            }

        }.bind(this))
    };

    /**
     * @param areaToPrint
     * @param opt
     * @returns {{$el: jQuery, css: Object}}
     */
    joint.dia.Paper.prototype.preparePrintArea = function(areaToPrint, opt) {

        this.trigger('beforeprint', opt);

        var $printArea = $('<div/>').addClass('printarea');

        // deprecated option
        if (opt.size) {
            $printArea.addClass('printarea-size-' + opt.size);
        }

        var scale = this.scale();
        this.scale(1);

        var $printPaper = this.$el.clone().appendTo($printArea);

        var viewBox = getViewBox(this.getArea(), areaToPrint, opt);
        var rect = viewBox.rect;
        var scaleToFit = viewBox.scaleToFit;

        $printPaper.css({
            left: 0,
            top: 0,
            width: '200%',
            height: '200%'
        });

        V($printPaper.find('svg')[0]).attr({
            width: rect.width,
            height: rect.height,
            viewBox: [rect.x, rect.y, rect.width, rect.height].join(' ')
        });

        var gridSize = this.options.gridSize;
        if (gridSize > 1) {
            var $printPaperGrid = $printArea.find('.joint-paper-grid');
            $printPaperGrid.css({
                transform: ['translate(', -rect.x % gridSize, 'px, ', -rect.y % gridSize, 'px)'].join('')
            });
        }

        this.scale(scale.sx, scale.sy);

        $printArea.addClass('preview');
        return {
            $el: $printArea,
            css: {
                width: rect.width + 'px',
                height: rect.height + 'px',
                transform: 'scale(' + scaleToFit + ')',
                'transform-origin': '0 0'
            }
        };
    };

    var objectToCss = function(obj) {

        return Object.keys(obj).map(function(key) {
            return key + ':' + obj[key];
        }).join(';') + ';';
    };

    var getSheetSizePx = function(sheet, margin) {

        var widthReduction = convert.toPx(margin.left + margin.right, margin.unit);
        var heightReduction = convert.toPx(margin.top + margin.bottom, margin.unit);

        return {
            width: Math.max(convert.toPx(sheet.width, sheet.unit) - widthReduction, 1),
            height: Math.max(convert.toPx(sheet.height, sheet.unit) - heightReduction, 1)
        };
    };

    var getViewBox = function(paperAreaBBox, areaToPrint, opt) {

        var rect = g.Rect({
            x: (areaToPrint.x - paperAreaBBox.x),
            y: (areaToPrint.y - paperAreaBBox.y),
            width: areaToPrint.width,
            height: areaToPrint.height
        });

        var margin = joint.util.normalizeSides(opt.margin);
        var sheet = opt.sheet;
        margin.unit = opt.marginUnit;
        sheet.unit = opt.sheetUnit;
        var sheetSizePx = getSheetSizePx(sheet, margin);

        var viewBoxRatio = rect.width / rect.height;
        var sheetRatio = sheetSizePx.width / sheetSizePx.height;
        var scaleToFit;

        if (viewBoxRatio > sheetRatio) {
            scaleToFit = sheetSizePx.width / rect.width;
        } else {
            scaleToFit = sheetSizePx.height / rect.height;
        }

        return { rect: rect, scaleToFit: scaleToFit };
    };

    var resolveOptions = function(opt) {

        var options = joint.util.defaultsDeep({}, opt, {
            area: null,
            poster: false,
            sheet: {
                width: 210,
                height: 297
            },
            // support mm, in, pt, pc, cm,
            // 1 in = 2.54cm = 25.4mm = 72pt = 6pc
            sheetUnit: 'mm',
            ready: function($printArea, readyToPrint) {
                readyToPrint($printArea);
            },

            margin: 0.4,
            marginUnit: 'in',
            // applicable only if area is not defined
            padding: 5

            // @deprecated - backward compatibility
            // For setting actual paper print size via CSS.
            // Adds another class to printarea <div/> like `printarea-size-a4`.
            //
            // CSS:
            // .printarea-size-a4 {
            //      width: 210mm !important;
            //      height: 297mm !important;
            // }

            // size: 'a4'
        });

        if (!options.area) {
            options.printingAll = true;
        }

        return options;
    };

    var injectCss = function(cssString) {

        var stylesCssEl = $('#print-styles');

        var style = '<style type="text/css" id="print-styles">' + cssString + '</style>';
        if (stylesCssEl.length) {
            stylesCssEl.html(cssString);
        } else {
            $('head').append(style);
        }
    };

    var injectPrintCss = function(printAreaObjCss, opt) {

        var printAreaCssValue = objectToCss(printAreaObjCss);
        var margin = joint.util.normalizeSides(opt.margin);
        var unit = opt.marginUnit;

        var pageMarginCssValue = [margin.top + unit, margin.right + unit, margin.bottom + unit, margin.left + unit].join(' ');
        var orientation = opt.sheet.width > opt.sheet.height ? 'landscape' : 'portrait';

        var printCss = [
            '@media print {',
            '.printarea.print-ready {',
            printAreaCssValue,
            '}',
            '@page {',
            'margin:' + pageMarginCssValue + ';',
            'size:' + orientation + ';',
            '}',
            '}',
            '.printarea.preview {',
            printAreaCssValue,
            '}'
        ];
        injectCss(printCss.join(''));
    };

    var getArea = function(opt) {

        var area = opt.area;
        // backward compatibility
        if (!area) {

            var padding = joint.util.normalizeSides(opt.padding);
            area = this.getContentArea().moveAndExpand({
                x: -padding.left,
                y: -padding.top,
                width: padding.left + padding.right,
                height: padding.top + padding.bottom
            });
        }

        return area;
    };

    var splitArea = function(area, chunkSize) {

        var w = chunkSize.width;
        var h = chunkSize.height;

        var chunk;
        var res = [];

        var rowsHeight = 0;
        var colsWidth = 0;
        var rows = 0;
        var columns = 0;

        while (rowsHeight < area.height) {
            while (colsWidth < area.width) {
                chunk = g.Rect(area.x + colsWidth, area.y + rowsHeight, w, h);
                res.push(chunk);
                colsWidth += w;
                if (columns > MAX_COLUMNS) {
                    break;
                }
                columns++;
            }
            colsWidth = 0;
            columns = 0;
            rowsHeight += h;
            if (rows > MAX_ROWS) {
                break;
            }
            rows++
        }

        return res.reverse();
    };

    var getPosterPieceSize = function(area, opt) {

        var pieceSize = {
            width: opt.width,
            height: opt.height
        };

        if (!pieceSize.width) {
            pieceSize.width = Math.ceil(area.width / (opt.columns || 1));
        }

        if (!pieceSize.height) {
            pieceSize.height = Math.ceil(area.height / (opt.rows || 1));
        }

        return pieceSize;
    };

    var convert = {

        supportedUnits: {
            'px': function(value) {
                return value;
            },
            'mm': function(value) {
                return this.millimeterSize * value;
            },
            'cm': function(value) {
                return (this.millimeterSize * value) * 10;
            },
            'in': function(value) {
                return this.millimeterSize * value * 25.4;
            },
            'pt': function(value) {
                return this.millimeterSize * ((value * 25.4) / 72);
            },
            'pc': function(value) {
                return this.millimeterSize * ((value * 25.4) / 6);
            }
        },

        measureMillimeter: function() {

            var box = $('<div/>').css({
                display: 'inline-block',
                position: 'absolute',
                left: -5000,
                width: '1mm',
                height: '1mm'
            }).appendTo(document.body);

            var width = box.width();
            box.remove();

            return width;
        },

        toPx: function(value, unit) {

            if (!this.millimeterSize) {
                this.millimeterSize = this.measureMillimeter();
            }

            unit = (unit || '').toLowerCase();

            if (!this.supportedUnits[unit]) {
                throw new Error('Unsupportted unit ' + unit);
            }

            return this.supportedUnits[unit].call(this, value);
        }
    };

})($, V, joint);
