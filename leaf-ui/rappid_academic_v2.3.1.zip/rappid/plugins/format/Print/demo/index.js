/*! Rappid v2.3.1 - HTML5 Diagramming Framework

Copyright (c) 2015 client IO

 2018-05-17 


This Source Code Form is subject to the terms of the Rappid Academic License
, v. 1.0. If a copy of the Rappid License was not distributed with this
file, You can obtain one at http://jointjs.com/license/rappid_academic_v1.txt
 or from the Rappid archive as was distributed by client IO. See the LICENSE file.*/


var graph = new joint.dia.Graph;
var $paper = $('#paper');
var $printPreview = $('.print-preview');

var options = {
    paper: { gridSize: 50, scale: 0.5, translateX: 0, translateY: 0 },
    print: { padding: 0, sheet: {}, margin: 0, marginUnit: 'in' },
    'Print Area': true,

    'columns / rows': false,
    rows: 2,
    columns: 2,

    'width / height': false,
    width: 200,
    height: 150,
    marginUnits: {
        mm: 'mm',
        cm: 'cm',
        in: 'in',
        pt: 'pt',
        pc: 'pc'
    },
    sheetTypes: {
        'A0': { width: 841, height: 1189, unit: 'mm' },
        'A3': { width: 297, height: 420, unit: 'mm' },
        'A4 (default)': { width: 210, height: 297, unit: 'mm' },
        'A5': { width: 148, height: 210, unit: 'mm' },
        'A10': { width: 27, height: 37, unit: 'mm' },
        'legal': { width: 8.5, height: 14, unit: 'in' },
        'letter': { width: 8.5, height: 11.0, unit: 'in' },
        'half-letter': { width: 5.5, height: 8.5, unit: 'in' },
        'junior-legal': { width: 5, height: 8.0, unit: 'in' },
        'LANDSCAPE - A4': { width: 297, height: 210, unit: 'mm' },
        'LANDSCAPE - A5': { width: 210, height: 148, unit: 'mm' },
        'LANDSCAPE - legal': { width: 14, height: 8.5, unit: 'in' }
    },

    getAreaOpt: function() {
        return this['Print Area'] ? areaTool.getBBox().moveAndExpand({ width: 1, height: 1 }) : null
    },

    getPosterOpt: function() {

        var posterOpt = null;
        if (this['columns / rows']) {
            posterOpt = {};
            posterOpt.rows = this.rows;
            posterOpt.columns = this.columns;
        }

        if (this['width / height']) {
            posterOpt = posterOpt || {};
            posterOpt.width = this.width;
            posterOpt.height = this.height;
        }

        return posterOpt;
    }
};

var paper = new joint.dia.Paper({
    el: $paper,
    width: 850,
    height: 450,
    gridSize: options.paper.gridSize,
    drawGrid: { name: 'mesh', args: { color: 'gray' } },
    model: graph
});

paper.scale(options.paper.scale);

$('#print-btn').click(function() {

    toogleAreaTool(false);

    var opt = {
        padding: options.print.padding,
        sheet: options.print.sheet,
        area: options.getAreaOpt(),
        poster: options.getPosterOpt(),
        margin: options.print.margin,
        marginUnit: options.print.marginUnit
    };

    console.log(opt);

    paper.print(opt);
    toogleAreaTool(options['Print Area']);

}.bind(paper));


$('#preview-btn').click(function() {

    toogleAreaTool(false);
    $printPreview.empty();
    var opt = {
        padding: options.print.padding,
        sheet: options.print.sheet,
        area: options.getAreaOpt(),
        poster: options.getPosterOpt(),
        /**
         * @param {Array<jQuery>} printAreaElements
         * @param {function} readyToPrint
         */
        ready: function(printAreaElements, readyToPrint) {
            var x = $('<div/>').css({ overflow: 'auto', height: 600 });
            printAreaElements.forEach(function($el) {
                $el.prependTo(x)
                    .css({
                        transform: 'none',
                        margin: 20,
                        border: '1px solid red',
                        display: 'inline-block'
                    })
                    .find('#paper')
                    .css('border', 'none');
            });

            var titlesuffix = '';
            if (options['Print Area']) {
                var area = areaTool.getBBox();
                titlesuffix = 'of area ' + area.width + ' x ' + area.height;
            }

            var dialog = new joint.ui.Dialog({
                width: '95%',
                title: 'Preview ' + titlesuffix,
                content: x,
                buttons: [
                    { action: 'close', content: 'Close' }
                ]
            });

            dialog.on('action:close', dialog.close, dialog);
            dialog.open();

            readyToPrint(false)
        }
    };

    console.log('preview options', opt);
    paper.print(opt);
    setTimeout(toogleAreaTool.bind(this, options['Print Area']), 220);

}.bind(paper));

// Area tool
var areaTooTransform;
var areaTool = new joint.shapes.standard.Rectangle({
    attrs: {
        body: {
            fill: '#f9a825',
            opacity: 0.9,
            stroke: '#263238'
        },
        label: {
            text: 'Print Area'
        }
    }
}).position(20, 20).size(400, 460);

paper.on('element:pointerup', function(cellView) {
    var cell = cellView.model;

    areaTooTransform = new joint.ui.FreeTransform({
        cellView: cellView,
        allowRotation: false,
        preserveAspectRatio: !!cell.get('preserveAspectRatio'),
        allowOrthogonalResize: cell.get('allowOrthogonalResize') !== false
    }).render();
});

// eslint-disable-next-line
SampleGraph(graph).create();
areaTool.addTo(graph);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// utils

function toogleAreaTool(show) {
    $(dgPadding.domElement).closest('li').toggle(!show);
    if (show) {
        if (!areaTool.findView(paper)) {
            paper.renderView(areaTool);
        }
    } else {
        if (areaTooTransform) {
            areaTooTransform.remove();
        }
        paper.removeView(areaTool);
    }
}

function togglePosterColumnsRows(show) {
    $(dgColumns.domElement).closest('li').toggle(show);
    $(dgRows.domElement).closest('li').toggle(show);
}

function togglePosterWH(show) {
    $(dgWidth.domElement).closest('li').toggle(show);
    $(dgHeight.domElement).closest('li').toggle(show);
}

// eslint-disable-next-line no-undef
var gui = new dat.GUI();
var optPaper = gui.addFolder('Paper Options');
var optPrint = gui.addFolder('Print Options');
var optBatchRC = gui.addFolder('Print Options - Poster - rows / columns');
var optBatchWH = gui.addFolder('Print Options - Poster - width / height');
optPaper.open();
optPrint.open();
optBatchRC.open();
optBatchWH.open();

optPaper.add(options.paper, 'gridSize', 5, 100).step(1).onChange(function(value) {
    paper.options.gridSize = value;
    paper.drawGrid();
});

optPaper.add(options.paper, 'scale', 0.2, 10).step(0.2).onChange(paper.scale.bind(paper));
optPaper.add(options.paper, 'translateX', -400, 400).step(1).onChange(paper.setOrigin.bind(paper));
optPaper.add(options.paper, 'translateY', -400, 400).step(1).onChange(paper.setOrigin.bind(paper, options.paper.translateX));

optPrint.add(options.print, 'sheet', Object.keys(options.sheetTypes)).onChange(function(value) {
    options.print.sheet = options.sheetTypes[value];
    options.print.sheetUnit = options.sheetTypes[value].unit;
});

optPrint.add(options, 'Print Area').onChange(function(value) {
    options['Print Area'] = value;
    toogleAreaTool(value);
});

optBatchRC.add(options, 'columns / rows').onChange(function(value) {
    options['columns / rows'] = value;
    togglePosterColumnsRows(value);
});

optBatchWH.add(options, 'width / height').onChange(function(value) {
    options['width / height'] = value;
    togglePosterWH(value);
});

var dgPadding = optPrint.add(options.print, 'padding', 0, 50).step(1);
optPrint.add(options.print, 'margin', 0, 10).step(0.2);
optPrint.add(options.print, 'marginUnit', Object.keys(options.marginUnits)).onChange(function(value) {
    options.print.marginUnit = value;
});

var dgColumns = optBatchRC.add(options, 'columns', 1, 6).step(1);
var dgRows = optBatchRC.add(options, 'rows', 1, 6).step(1);
var dgWidth = optBatchWH.add(options, 'width', 50, 800).step(1);
var dgHeight = optBatchWH.add(options, 'height', 50, 800).step(1);

toogleAreaTool(options['Print Area']);
togglePosterColumnsRows(options['columns / rows']);
togglePosterWH(options['width / height']);
